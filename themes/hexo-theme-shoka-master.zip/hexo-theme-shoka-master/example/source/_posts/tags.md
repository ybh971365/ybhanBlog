title: Tags
date: 2013-12-24 23:29:53
tags:
- Foo
- Bar
- Baz
---

This post contains 3 tags. Make sure your theme can display all of the tags.