title: Gallery Post
date: 2013-12-25 00:16:18
photos:
- assets/wallpaper-2572384.jpg
- assets/wallpaper-2311325.jpg
- assets/wallpaper-878514.jpg
- http://placehold.it/350x150.jpg
---

This post contains 4 photos:

- Widescreen wallpaper
- Portrait photo
- Dual widescreen wallpaper
- Small photo

All photos should be displayed properly.

*From [Wallbase.cc](http://wallbase.cc)*